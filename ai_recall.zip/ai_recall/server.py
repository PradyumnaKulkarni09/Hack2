"""Local web UI. Standard library only (no pip packages) and no external assets, so it works fully offline.

  python server.py                          # http://127.0.0.1:8765
  python server.py --watch data\\edge.log    # also ingest new log lines live while the UI is open
  python server.py --llm --embedder ollama  # optional model-backed planning / embeddings (see README)

Binds to 127.0.0.1 only. Nothing is reachable from other machines.
"""
import argparse
import json
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from airecall import anomaly
from airecall.engine import Recall

ROOT = Path(__file__).parent
LIVE = dict(path=None, batches=0, lines=0, last=None)
CACHE = dict(n=-1, found=[])


def downsample(rows, n=600):
    """Keep the min and max of every bucket so short spikes survive."""
    if len(rows) <= n:
        return rows
    step, out = len(rows) / (n // 2), []
    for i in range(n // 2):
        seg = rows[int(i * step):int((i + 1) * step)]
        if seg:
            pts = {id(min(seg, key=lambda r: r[1])): min(seg, key=lambda r: r[1]),
                   id(max(seg, key=lambda r: r[1])): max(seg, key=lambda r: r[1])}
            out.extend(sorted(pts.values(), key=lambda r: r[0]))
    return out


def make_handler(eng, port):
    page = (ROOT / "web" / "index.html").read_bytes()
    ok_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, obj, code=200, ctype="application/json; charset=utf-8"):
            body = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def _guard(self):  # blocks DNS-rebinding style requests from other sites
            if self.headers.get("Host", "") not in ok_hosts:
                self._send({"error": "bad host"}, 403)
                return False
            return True

        def do_GET(self):
            if not self._guard():
                return
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            try:
                if u.path == "/":
                    self._send(page, ctype="text/html; charset=utf-8")
                elif u.path == "/favicon.ico":
                    self._send(b"", 204, "image/x-icon")
                elif u.path == "/api/info":
                    with eng.lock:
                        s = eng.store
                        info = dict(logs=s.n_logs(), templates=len(s.tmpl), nodes=s.nodes(), fields=s.metric_names(),
                                    first=s.first_ts(), last=s.latest_ts(), embedder=eng.emb.name, device=eng.emb.device,
                                    llm=eng.use_llm, live=dict(LIVE))
                    self._send(info)
                elif u.path == "/api/series":
                    with eng.lock:
                        rows = eng.store.series(q.get("field", ""), q.get("node", ""), 200000)
                    self._send(downsample(rows))
                elif u.path == "/api/anomalies":
                    with eng.lock:
                        n = eng.store.n_logs()
                        if n != CACHE["n"]:
                            CACHE.update(n=n, found=anomaly.scan_all(eng.store))
                        found = CACHE["found"]
                    self._send([dict(i, text=anomaly.describe(i)) for i in found[:60]])
                else:
                    self._send({"error": "not found"}, 404)
            except Exception as e:
                self._send({"error": str(e)}, 500)

        def do_POST(self):
            if not self._guard():
                return
            if urlparse(self.path).path != "/api/ask":
                return self._send({"error": "not found"}, 404)
            try:
                n = int(self.headers.get("Content-Length", 0))
                if n > 65536:
                    return self._send({"error": "too large"}, 413)
                question = str(json.loads(self.rfile.read(n)).get("q", ""))[:2000].strip()
                if not question:
                    return self._send({"error": "empty question"}, 400)
                self._send(eng.ask(question))
            except Exception as e:
                self._send({"error": str(e)}, 500)

    return H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--embedder", default="auto", choices=["auto", "hash", "onnx", "ollama"])
    ap.add_argument("--provider", default="auto", choices=["auto", "cpu", "qnn"])
    ap.add_argument("--llm", action="store_true")
    ap.add_argument("--watch", metavar="LOGFILE", help="ingest new lines from this file while running")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--open", action="store_true", help="open the browser")
    a = ap.parse_args()

    eng = Recall(a.data, a.embedder, a.provider, a.llm)
    stop = threading.Event()
    if a.watch:
        LIVE["path"] = a.watch

        def batch(st):
            LIVE["batches"] += 1
            LIVE["lines"] += st["parsed"]
            LIVE["last"] = time.strftime("%H:%M:%S")
        threading.Thread(target=eng.watch, kwargs=dict(path=a.watch, interval=1.0, stop=stop, on_batch=batch),
                         daemon=True).start()
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), make_handler(eng, a.port))
    url = f"http://127.0.0.1:{a.port}"
    print(f"AI Recall UI on {url}  (embedder {eng.emb.name}/{eng.emb.device}, LLM {'on' if eng.use_llm else 'off'}"
          f"{', watching ' + a.watch if a.watch else ''}). Ctrl+C to stop.")
    if a.open:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        srv.server_close()


if __name__ == "__main__":
    main()
