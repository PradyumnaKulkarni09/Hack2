"""Synthetic edge-device log generator with injected anomalies and saved ground truth.

Line format:  2026-10-20T14:03:22 edge-03 INFO metric voltage=231.2 temp=40.1 current=3.20
Usage:        python gen_logs.py --days 3 --out data/edge.log
"""
import argparse
import json
import math
import random
from datetime import datetime, timedelta
from pathlib import Path

NODES = [f"edge-{i:02d}" for i in range(1, 6)]
SPIKE_LIMIT = 250.0  # voltage above this is an incident


def fmt(t):
    return t.strftime("%Y-%m-%dT%H:%M:%S")


def generate(days=3, out="data/edge.log", seed=7, end=None, step_s=60):
    rnd = random.Random(seed)
    end = end or datetime.now().replace(second=0, microsecond=0)
    start = end - timedelta(days=days)
    n_steps = int(days * 86400 / step_s)

    # Pick incident times per node, keeping them apart so ground truth is unambiguous.
    incidents = {}
    plan = (("voltage_spike", (3, 6)), ("link_down", (2, 4)), ("over_temp", (1, 2)),
            ("sensor_timeout", (2, 4)), ("firmware_update", (1, 1)))
    for node in NODES:
        for kind, (lo, hi) in plan:
            for _ in range(rnd.randint(lo, hi)):
                s = rnd.randint(30, n_steps - 30)
                while any((node, s + d) in incidents for d in range(-8, 9)):
                    s = rnd.randint(30, n_steps - 30)
                incidents[(node, s)] = kind

    truth = {k: [] for k, _ in plan}
    rows = []  # (ts_string, text)

    def emit(t, node, level, msg):
        rows.append((fmt(t), f"{fmt(t)} {node} {level} {msg}"))

    for node in NODES:
        base_v = 230 + rnd.uniform(-2, 2)
        base_t = 40 + rnd.uniform(-3, 3)
        for s in range(n_steps):
            t = start + timedelta(seconds=s * step_s)
            hour = t.hour + t.minute / 60
            temp = base_t + 4 * math.sin((hour - 9) / 24 * 2 * math.pi) + rnd.gauss(0, 0.6)
            volt = base_v + rnd.gauss(0, 1.5)
            cur = 3.0 + 0.4 * math.sin(hour / 24 * 2 * math.pi) + rnd.gauss(0, 0.15)
            kind = incidents.get((node, s))

            if kind == "voltage_spike":
                volt = rnd.uniform(SPIKE_LIMIT + 5, 285)
                emit(t, node, "WARN", "voltage spike detected on supply rail, exceeds configured limit")
            elif kind == "over_temp":
                temp = rnd.uniform(88, 95)
                emit(t, node, "CRIT", "over temperature shutdown triggered, node entering safe mode")
            elif kind == "link_down":
                emit(t, node, "ERROR", "link down on interface eth0")
                emit(t + timedelta(seconds=step_s * rnd.randint(2, 6)), node, "INFO", "link up on interface eth0")
            elif kind == "sensor_timeout":
                emit(t, node, "ERROR", f"sensor read timeout on channel {rnd.randint(1, 4)}")
            elif kind == "firmware_update":
                emit(t, node, "INFO", "firmware update started version=1.4.2")
                emit(t + timedelta(seconds=step_s * 3), node, "INFO", "firmware update completed version=1.4.2")
            if kind:
                truth[kind].append({"node": node, "ts": fmt(t)})

            emit(t, node, "INFO", f"metric voltage={volt:.1f} temp={temp:.1f} current={cur:.2f}")

            r = rnd.random()
            if r < 0.002:
                emit(t, node, "WARN", f"network latency high to gateway latency_ms={rnd.randint(150, 900)}")
            elif r < 0.0025:
                emit(t, node, "WARN", f"disk usage high disk_pct={rnd.randint(85, 97)}")
            elif r < 0.003:
                emit(t, node, "INFO", "configuration reloaded")

    rows.sort(key=lambda x: x[0])
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(r[1] for r in rows) + "\n", encoding="utf-8")
    for v in truth.values():
        v.sort(key=lambda d: d["ts"])
    meta = {"spike_limit": SPIKE_LIMIT, "start": fmt(start), "end": fmt(end), "lines": len(rows), "truth": truth}
    (out.parent / "ground_truth.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def live(path, interval=2.0, spike_prob=0.05, step_s=60, max_ticks=None):
    """Append new log lines forever (one simulated minute per tick) so you can demo live ingestion.
    Continues from the last timestamp already in the file. Ctrl+C to stop."""
    import time
    rnd = random.Random()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    last = datetime.now().replace(second=0, microsecond=0) - timedelta(seconds=step_s)
    if path.exists() and path.stat().st_size:
        with open(path, "rb") as f:
            f.seek(max(0, path.stat().st_size - 4096))
            tail = f.read().decode("utf-8", "replace").strip().splitlines()
        if tail:
            try:
                last = datetime.fromisoformat(tail[-1].split()[0])
            except ValueError:
                pass
    base = {n: (230 + rnd.uniform(-2, 2), 40 + rnd.uniform(-3, 3)) for n in NODES}
    ticks = 0
    while max_ticks is None or ticks < max_ticks:
        last += timedelta(seconds=step_s)
        lines = []
        for node in NODES:
            bv, bt = base[node]
            volt, temp, cur = bv + rnd.gauss(0, 1.5), bt + rnd.gauss(0, 0.6), 3.0 + rnd.gauss(0, 0.15)
            if rnd.random() < spike_prob / len(NODES):
                volt = rnd.uniform(SPIKE_LIMIT + 5, 285)
                lines.append(f"{fmt(last)} {node} WARN voltage spike detected on supply rail, exceeds configured limit")
            lines.append(f"{fmt(last)} {node} INFO metric voltage={volt:.1f} temp={temp:.1f} current={cur:.2f}")
        with open(path, "a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        ticks += 1
        print(f"[live] {fmt(last)} +{len(lines)} lines", flush=True)
        time.sleep(interval)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", metavar="LOGFILE", help="keep appending simulated lines to this file (live demo)")
    ap.add_argument("--interval", type=float, default=2.0, help="seconds between simulated minutes (with --live)")
    ap.add_argument("--days", type=int, default=3)
    ap.add_argument("--out", default="data/edge.log")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--end", help="ISO end time, default now (e.g. 2026-10-26T12:00:00)")
    a = ap.parse_args()
    if a.live:
        try:
            live(a.live, a.interval)
        except KeyboardInterrupt:
            print("stopped")
        raise SystemExit
    end = datetime.fromisoformat(a.end) if a.end else None
    m = generate(a.days, a.out, a.seed, end)
    print(f"wrote {m['lines']} lines to {a.out}; ground truth in {Path(a.out).parent / 'ground_truth.json'}")
