# AI Recall: offline natural-language recall over edge logs

Ask "When was the last time voltage went above 250 on edge-03?" or "What happened around the last over
temperature shutdown?" and get the answer plus the exact log lines. Parsing, memory and answering run on this machine.
See `SOLUTION.md` for the architecture, results, demo script and limits.

Needs Python 3.10+ (works on 3.15) and **only numpy**. Everything else is optional.

## Quick start
```
python -m venv .venv
.venv\Scripts\activate            (PowerShell: .venv\Scripts\Activate.ps1)
pip install numpy
python main.py gen                          # synthetic logs + ground truth in data\
python main.py ingest data\edge.log --reset
python main.py ask "When was the last time voltage went above 250 on edge-03?" -v
python main.py chat
python main.py anomalies                    # unusual readings and silent nodes
python server.py --open                     # browser UI on http://127.0.0.1:8765 (no extra packages)
python eval.py                              # accuracy against injected ground truth
python offline_proof.py                     # runs everything with the network blocked, expects 0 attempts
```

## Live demo (three windows)
```
python gen_logs.py --live data\edge.log     # simulator appends a new minute every 2 s
python server.py --watch data\edge.log --open
```
Or `python main.py watch data\edge.log` to follow the file from the command line.

## Questions it understands
| Kind | Example |
|---|---|
| Last / first | When was the last time voltage went above 250 on edge-03? |
| Count | How many sensor read timeouts on node 2? |
| Max / min / average | Highest temperature on edge-01 |
| Events by meaning | When did edge-01 lose network connectivity? |
| State at a time | What was the state of edge-03 at 2026-11-17 13:29? |
| Context around an event | What happened around the last over temperature shutdown? |
| Time windows | Show errors in the last 12 hours |

If no threshold is given ("show the last voltage spike") a robust one is chosen and the answer says which.

## Optional: better meaning matching (neural embeddings)
- **No extra pip packages (works on any Python):** install Ollama, run `ollama pull all-minilm`, then add `--embedder ollama` to any command, or `server.py --embedder ollama`.
- **ONNX (needs onnxruntime wheels for your Python):** `python export_onnx.py`, then `--embedder onnx`. On a Snapdragon X laptop install `onnxruntime-qnn` and add `--provider qnn` to run on the NPU.

## Optional: LLM for planning and phrasing (Qwen3-4B-Instruct-2507)
PowerShell:
```
$env:RECALL_LLM_URL="https://<host>:<port>/V1/chat/completions"
$env:RECALL_LLM_MODEL="Qwen3-4B-Instruct-2507"
$env:RECALL_ALLOW_REMOTE="1"            # needed for any non-localhost host
$env:RECALL_INSECURE_TLS="1"            # self-signed cert on a private IP (or RECALL_CA_BUNDLE=<cert file>, preferred)
$env:RECALL_LLM_API_KEY="<key>"         # only if required
python check_llm.py                     # tests the endpoint and explains any error
python main.py ask "any weird voltage on node 3 recently" --llm -v
python eval.py --llm
```
Command Prompt: use `set NAME=value`. Questions and matching log lines go to that server, so use synthetic logs unless it is approved
for real data. State and context questions are always planned by rules.

## NPU path (Qualcomm AI Hub)
```
pip install qai-hub qai-hub-models torch transformers onnx onnxruntime tokenizers   (needs a Python with wheels, e.g. 3.11/3.12)
qai-hub configure --api_token <TOKEN>
python export_onnx.py
python aihub_compile.py --list-devices
python aihub_compile.py --device "Snapdragon X Elite"
python bench.py                          # hash vs ONNX-CPU vs ONNX-NPU latency
```
AI Hub uploads the model and sample inputs to Qualcomm. Use public models and synthetic data, and get IT approval first.

## Your own logs
Expected line: `YYYY-MM-DDTHH:MM:SS <node> <DEBUG|INFO|WARN|ERROR|CRIT> <message>`. Numeric fields come from `name=number` pairs in the message.
Different format? Edit `LINE` in `airecall\logparse.py`. For free-text logs replace `make_template` with Drain3.

## Files
`main.py` CLI · `server.py` + `web\index.html` browser UI · `airecall\` engine (logparse, store, embedder, nlq, llm, anomaly, engine)
· `gen_logs.py` data and live simulator · `eval.py` · `offline_proof.py` · `check_llm.py` · `export_onnx.py`, `aihub_compile.py`, `bench.py` NPU path
· `app.py` optional Streamlit UI (needs streamlit, which may lack wheels on very new Python).

## Known limits
- Relative times are relative to the newest log line. Evaluation uses synthetic data.
- The built-in embedder handles common paraphrases only; use a neural embedder for general phrasing.
- No voice input yet. See `SOLUTION.md` for the full list.
