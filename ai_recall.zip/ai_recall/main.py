"""AI Recall command line.

  python main.py gen                      # make synthetic logs in data/
  python main.py ingest data/edge.log --reset
  python main.py ask "When was the last time voltage went above 250 on edge-03?"
  python main.py chat
  python main.py info
"""
import argparse
import json
import sys

from airecall import anomaly
from airecall.engine import Recall


def show(res, verbose=False):
    print("\n" + res["answer"])
    for e in res["evidence"][:5]:
        extra = f"  [{e['value']:g}]" if "value" in e else ""
        print(f"   - {e['ts']} {e['node']} {e['level']:<5} {e['msg']}{extra}")
    print(f"   ({res['latency_ms']} ms)")
    if verbose:
        print("   plan:", json.dumps(res["plan"]))
        for m in res["matched"]:
            print("   matched:", m)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["gen", "ingest", "ask", "chat", "info", "anomalies", "watch"])
    ap.add_argument("arg", nargs="?", help="file for ingest, question for ask")
    ap.add_argument("--data", default="data")
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("--embedder", default="auto", choices=["auto", "hash", "onnx", "ollama"])
    ap.add_argument("--provider", default="auto", choices=["auto", "cpu", "qnn"])
    ap.add_argument("--llm", action="store_true", help="use local LLM endpoint (RECALL_LLM_URL)")
    ap.add_argument("--days", type=int, default=3)
    ap.add_argument("--z", type=float, default=6.0, help="anomaly sensitivity (robust z-score)")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()

    if a.cmd == "gen":
        import gen_logs
        m = gen_logs.generate(days=a.days, out=f"{a.data}/edge.log")
        print(f"wrote {m['lines']} lines to {a.data}/edge.log (+ ground_truth.json)")
        return
    r = Recall(a.data, a.embedder, a.provider, a.llm)
    if a.cmd == "ingest":
        print(json.dumps(r.ingest(a.arg or f"{a.data}/edge.log", a.reset), indent=2))
    elif a.cmd == "anomalies":
        found = anomaly.scan_all(r.store, a.z)
        print(f"{len(found)} incident(s)")
        for inc in found:
            print("  " + anomaly.describe(inc))
    elif a.cmd == "watch":
        import time
        path = a.arg or f"{a.data}/edge.log"
        print(f"Watching {path} (Ctrl+C to stop). Ask questions meanwhile from another window.")

        def shown(st):
            print(f"[{time.strftime('%H:%M:%S')}] +{st['parsed']} lines, {st['new_templates']} new event type(s), "
                  f"total {r.store.n_logs()}", flush=True)
        try:
            r.watch(path, 1.0, on_batch=shown)
        except KeyboardInterrupt:
            print("stopped")
    elif a.cmd == "info":
        s = r.store
        print(f"logs={s.n_logs()} templates={len(s.tmpl)} nodes={s.nodes()} fields={s.metric_names()}")
        print(f"range={s.first_ts()} -> {s.latest_ts()}  embedder={r.emb.name} on {r.emb.device}")
    elif a.cmd == "ask":
        if not a.arg:
            sys.exit("give a question")
        show(r.ask(a.arg), a.verbose)
    else:
        print("Ask about your logs (blank line to quit).")
        while True:
            try:
                q = input("\n> ").strip()
            except EOFError:
                break
            if not q:
                break
            show(r.ask(q), a.verbose)


if __name__ == "__main__":
    main()
