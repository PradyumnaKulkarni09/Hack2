"""Prove that nothing leaves the device.

Runs the whole pipeline (generate, ingest, ask, time-travel, anomaly scan) with every non-loopback network
connection and DNS lookup BLOCKED and counted. Expected result: 0 attempts.
    python offline_proof.py
Uses a temporary folder, so your own data/ is untouched. (No LLM endpoint is configured for this run.)
"""
import os
import socket
import tempfile

os.environ.pop("RECALL_LLM_URL", None)
attempts = []
LOCAL = {"127.0.0.1", "::1", "localhost"}
_connect, _connect_ex, _gai = socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo


def _host(addr):
    return addr[0] if isinstance(addr, tuple) else None


def guard(real):
    def wrapped(self, addr, *a, **k):
        h = _host(addr)
        if h is not None and h not in LOCAL:
            attempts.append(h)
            raise OSError(f"BLOCKED outbound connection to {h}")
        return real(self, addr, *a, **k)
    return wrapped


def gai(host, *a, **k):
    if host not in LOCAL and host is not None:
        attempts.append(f"dns:{host}")
        raise OSError(f"BLOCKED DNS lookup for {host}")
    return _gai(host, *a, **k)


socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo = guard(_connect), guard(_connect_ex), gai

import gen_logs  # noqa: E402
from airecall import anomaly  # noqa: E402
from airecall.engine import Recall  # noqa: E402

with tempfile.TemporaryDirectory() as d:
    meta = gen_logs.generate(days=2, out=f"{d}/edge.log")
    r = Recall(d, "hash", use_llm=False)
    st = r.ingest(f"{d}/edge.log", reset=True)
    questions = ["When was the last time voltage went above 250 on edge-03?", "How many voltage spikes were there?",
                 "when did the link go down on node 2", "what happened around the last over temperature shutdown",
                 "highest temperature on edge-01", "show errors in the last 12 hours"]
    answered = sum(1 for q in questions if r.ask(q)["answer"])
    found = anomaly.scan_all(r.store)

print(f"ingested {st['parsed']:,} lines, answered {answered}/{len(questions)} questions, found {len(found)} incidents")
print(f"outbound network attempts: {len(attempts)}  {attempts if attempts else ''}")
print("PASS: fully offline" if not attempts else "FAIL: something tried to reach the network")
raise SystemExit(1 if attempts else 0)
