"""Streamlit UI:  streamlit run app.py"""
import pandas as pd
import streamlit as st

from airecall.engine import Recall

st.set_page_config(page_title="AI Recall", page_icon="🧠", layout="wide")


@st.cache_resource
def get_engine(embedder, provider, use_llm):
    return Recall("data", embedder, provider, use_llm)


with st.sidebar:
    st.header("AI Recall")
    embedder = st.selectbox("Embedder", ["auto", "hash", "onnx", "ollama"])
    provider = st.selectbox("ONNX provider", ["auto", "cpu", "qnn"], help="qnn = Qualcomm NPU (needs onnxruntime-qnn on Snapdragon)")
    use_llm = st.checkbox("Use local LLM (RECALL_LLM_URL)", value=False)
    eng = get_engine(embedder, provider, use_llm)
    st.caption(f"Embedding on: **{eng.emb.name} / {eng.emb.device}**")
    st.caption("Processing is local. No network calls are made except to a localhost LLM if enabled.")

    if st.button("Generate demo logs"):
        import gen_logs
        gen_logs.generate(days=3, out="data/edge.log")
        st.success("Generated data/edge.log")
    if st.button("Ingest data/edge.log (reset)"):
        with st.spinner("Ingesting..."):
            st.json(eng.ingest("data/edge.log", reset=True))
    up = st.file_uploader("Or append a log file", type=["log", "txt"])
    if up and st.button("Ingest upload"):
        st.json(eng.ingest_lines(up.getvalue().decode("utf-8", "replace").splitlines()))

s = eng.store
st.title("Ask your logs")
if not s.n_logs():
    st.info("No logs yet. Use the sidebar: Generate demo logs, then Ingest.")
    st.stop()

c1, c2, c3 = st.columns(3)
c1.metric("Log lines", f"{s.n_logs():,}")
c2.metric("Event templates", len(s.tmpl))
c3.metric("Range", f"{s.first_ts()[5:16]} → {s.latest_ts()[5:16]}")

examples = ["When was the last time voltage went above 250 on edge-03?", "How many voltage spikes were there?",
            "when did the link go down on node 2", "highest temperature on edge-01", "show errors in the last 12 hours"]
cols = st.columns(len(examples))
for col, ex in zip(cols, examples):
    if col.button(ex, use_container_width=True):
        st.session_state["q"] = ex

q = st.chat_input("e.g. Show me the last time the voltage log spiked above threshold")
q = q or st.session_state.pop("q", None)
if q:
    st.chat_message("user").write(q)
    res = eng.ask(q)
    with st.chat_message("assistant"):
        st.write(res["answer"])
        if res["evidence"]:
            df = pd.DataFrame(res["evidence"]).drop(columns=["id"])
            st.dataframe(df, use_container_width=True, hide_index=True)
        st.caption(f"{res['latency_ms']} ms · embedder {eng.emb.name} ({eng.emb.device})")
        with st.expander("How this was answered (query plan)"):
            st.json({"plan": res["plan"], "matched_templates": res["matched"]})

st.divider()
st.subheader("Timeline")
a, b = st.columns(2)
node = a.selectbox("Node", s.nodes())
field = b.selectbox("Field", s.metric_names())
data = s.series(field, node)
if data:
    st.line_chart(pd.DataFrame(data, columns=["ts", field]).set_index("ts"))
