"""Evaluate AI Recall against ground truth injected by gen_logs.py (data/ground_truth.json).

  python eval.py                # rules + hash embedder (offline, no model)
  python eval.py --llm          # same questions, with the LLM endpoint planning the query (see README)
  python eval.py --embedder ollama
Reports exact-answer accuracy per question type, recall@5 for lookups, latency, and the anomaly scanner's
recall of the injected incidents. Synthetic data, so read it as a regression test, not a real-world claim.
"""
import argparse
import csv
import json
import re
import statistics
from pathlib import Path

from airecall import anomaly
from airecall.engine import Recall

NODE_WORD = {"edge-01": "edge-01", "edge-02": "node 2", "edge-03": "device 3", "edge-04": "edge-04", "edge-05": "edge-05"}


def by_node(truth, kind):
    d = {}
    for e in truth[kind]:
        d.setdefault(e["node"], []).append(e["ts"])
    return d


def lead(res, node, ts):
    ev = res["evidence"]
    return bool(ev) and ev[0]["ts"] == ts and ev[0]["node"] == node


def top5(res, node, ts):
    return any(e["ts"] == ts and e["node"] == node for e in res["evidence"][:5])


def count_is(n):
    def f(res):
        m = re.search(r"(\d+)\s+(?:reading|matching)", res["answer"])
        return bool(m) and int(m.group(1)) == n
    return f


def build_cases(gt):
    t, limit = gt["truth"], gt["spike_limit"]
    C = []  # (kind, question, ok(res), hit5(res), expected)

    def add(kind, q, node, ts, ok=None, hit=None):
        C.append((kind, q, ok or (lambda r, n=node, s=ts: lead(r, n, s)), hit or (lambda r, n=node, s=ts: top5(r, n, s)), ts))

    for node, tss in by_node(t, "voltage_spike").items():
        w = NODE_WORD[node]
        add("last-numeric", f"When was the last time voltage went above {limit:g} on {w}?", node, tss[-1])
        add("first-numeric", f"first time voltage exceeded {limit:g} on {w}", node, tss[0])
        cn = count_is(len(tss))
        C.append(("count-numeric", f"How many times did voltage go above {limit:g} on {w}?", cn, cn, len(tss)))
        add("context", f"what happened around the last voltage spike on {w}", node, tss[-1])
        spaced = tss[-1].replace("T", " ")
        okv = lambda r: (lambda m: bool(m) and float(m.group(1)) > limit)(re.search(r"voltage ([\d.]+)", r["answer"]))
        C.append(("state", f"what was the state of {w} at {spaced}", okv, okv, tss[-1]))
        add("paraphrase", f"last time there was a power surge on {w}", node, tss[-1])
    for node, tss in by_node(t, "link_down").items():
        w = NODE_WORD[node]
        add("last-event", f"when did the link go down on {w}", node, tss[-1])
        add("paraphrase", f"when did {w} lose network connectivity", node, tss[-1])
    for node, tss in by_node(t, "over_temp").items():
        w = NODE_WORD[node]
        add("last-event", f"last over temperature shutdown on {w}", node, tss[-1])
        add("paraphrase", f"when did {w} last overheat", node, tss[-1])
    for node, tss in by_node(t, "sensor_timeout").items():
        w = NODE_WORD[node]
        cn = count_is(len(tss))
        C.append(("count-event", f"how many sensor read timeouts on {w}", cn, cn, len(tss)))
        add("last-event", f"latest sensor timeout on {w}", node, tss[-1])
        add("paraphrase", f"last time a sensor on {w} stopped responding", node, tss[-1])
    return C


def anomaly_recall(store, truth):
    found = [i for i in anomaly.scan_all(store) if i["kind"] == "metric"]
    total = hit = 0
    for kind, field in (("voltage_spike", "voltage"), ("over_temp", "temp")):
        for e in truth[kind]:
            total += 1
            hit += any(i["node"] == e["node"] and i["field"] == field and i["start"] <= e["ts"] <= i["end"] for i in found)
    truth_keys = {(e["node"], e["ts"], k) for k, f in (("voltage", "voltage_spike"), ("temp", "over_temp")) for e in truth[f]}
    extra = [i for i in found if not any(i["node"] == n and i["field"] == k and i["start"] <= ts <= i["end"] for n, ts, k in truth_keys)]
    return hit, total, len(extra)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--embedder", default="auto")
    ap.add_argument("--provider", default="auto")
    ap.add_argument("--llm", action="store_true", help="use the LLM endpoint (RECALL_LLM_URL) for planning")
    ap.add_argument("--reset", action="store_true")
    a = ap.parse_args()

    gt = json.loads((Path(a.data) / "ground_truth.json").read_text())
    r = Recall(a.data, a.embedder, a.provider, a.llm)
    if a.reset or not r.store.n_logs():
        print(r.ingest(f"{a.data}/edge.log", reset=True))

    rows, lat, misses = [], [], []
    for kind, q, ok, hit, expect in build_cases(gt):
        res = r.ask(q)
        lat.append(res["latency_ms"])
        rows.append([kind, q, expect, int(bool(ok(res))), int(bool(hit(res))), res["latency_ms"]])
        if not ok(res):
            misses.append((q, expect, res["answer"][:110]))

    print(f"\nembedder: {r.emb.name} on {r.emb.device} | planner: {'LLM + rules' if r.use_llm else 'rules'}")
    print(f"{'type':<15}{'n':>4}{'exact':>8}{'recall@5':>10}")
    for k in sorted({x[0] for x in rows}):
        rs = [x for x in rows if x[0] == k]
        print(f"{k:<15}{len(rs):>4}{sum(x[3] for x in rs) / len(rs):>8.0%}{sum(x[4] for x in rs) / len(rs):>10.0%}")
    print(f"{'ALL':<15}{len(rows):>4}{sum(x[3] for x in rows) / len(rows):>8.0%}{sum(x[4] for x in rows) / len(rows):>10.0%}")
    print(f"latency ms: median {statistics.median(lat):.1f}, p95 {sorted(lat)[max(0, int(0.95 * len(lat)) - 1)]:.1f}")
    h, tot, extra = anomaly_recall(r.store, gt["truth"])
    print(f"anomaly scan: found {h}/{tot} injected voltage/temperature incidents, {extra} extra flagged")
    for q, expect, got in misses:
        print("MISS:", q, "| expected", expect, "| got:", got)
    out = Path(a.data) / "eval_report.csv"
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["type", "question", "expected", "exact", "recall_at_5", "latency_ms"])
        w.writerows(rows)
    print("saved", out)


if __name__ == "__main__":
    main()
