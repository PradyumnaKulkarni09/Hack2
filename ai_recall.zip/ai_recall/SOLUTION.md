# AI Recall: solution write-up

Category: Technology Demonstrator (proof-point). Status as of 18 Nov 2026.

## 1. The problem (from the problem statement)
Enterprises produce huge volumes of operational and machine-to-machine logs. Getting useful answers out of
logs from distributed edge nodes is blocked by **cost** and by **data sovereignty and privacy exposure**
(logs normally have to leave the site to be analysed). The brief asks for an "AI Recall" framework on
Qualcomm edge hardware that runs **100% locally** to ingest, understand and recall historical log states
through natural-language questions, for example *"Show me the last time the voltage log spiked above threshold."*

## 2. What was built, mapped to the brief

| Requirement in the brief | What the demo does | Where | Status |
|---|---|---|---|
| Runs 100% locally | No cloud calls by default. `offline_proof.py` blocks and counts every non-loopback connection while running the whole pipeline. Result: 0 attempts. | `offline_proof.py` | Tested |
| Ingest continuous log streams | `watch` follows a growing file, ingests new complete lines within about a second, resumes after restart. A simulator produces a live stream. | `engine.watch`, `gen_logs.py --live` | Tested |
| Understand logs | Parser extracts time, node, level, numeric fields and a message template. | `logparse.py` | Tested on synthetic format |
| Local vector memory | One embedding per event template stored next to a SQLite table of all readings. | `store.py`, `embedder.py` | Tested |
| Recall historical states in natural language | last / first / count / max / min / average, **state at a given time**, and **context around an event** ("what happened around the last over temperature shutdown?"). | `nlq.py`, `engine.py` | Tested |
| NPU-accelerated semantic model | Embedding model exports to a static-shape ONNX file, runs through the QNN execution provider on Snapdragon, and `aihub_compile.py` compiles, profiles and verifies it on a cloud Qualcomm device. | `export_onnx.py`, `aihub_compile.py`, `bench.py` | **Written, not run on real NPU hardware** |
| Small language model | Qwen3-4B-Instruct-2507 turns questions into a structured query and phrases the answer. Optional, with a rule-based fallback. | `llm.py`, `check_llm.py` | Tested with a stand-in server; the real endpoint was reachable on your side only |
| Local UI for operators | Browser dashboard served from this machine: chat, source log lines, timeline with markers, unusual-activity list, live badge. No external assets. | `server.py`, `web/index.html` | Tested in headless Chromium |
| Voice queries | **Not built.** See roadmap. | | Gap |

Added beyond the brief: proactive **anomaly detection** and **silent-node detection** (missing logs are a signal).

## 3. Architecture

```
 log stream / files
        |
   [ watch / ingest ]  -> parse -> template + numeric fields
        |
        +--> SQLite: logs, metrics (exact numbers)         \
        +--> template vectors (embedding model, NPU-able)    }  all on the device
        |                                                   /
 question (text) --> planner --> structured query ----------+--> answer + the log lines it came from
                   (rules; optional local LLM)               |
                                                             +--> timeline, anomalies (UI)
```

Design decisions worth stating in the pitch:
1. **Numbers are never left to the model.** "Above 250" becomes SQL, so it is exact. The model only plans and phrases.
2. **Embeddings per template, not per line.** 21,745 log lines reduce to 11 event types, so memory stays tiny and
   embedding cost does not grow with log volume. That is what makes the NPU path cheap.
3. **Rules first, model optional.** The demo works with no model; the LLM improves phrasing and odd questions.
4. **Every answer cites its source lines**, so operators can verify it.

## 4. Results (synthetic data: 5 nodes, 3 days, 21,745 lines, injected incidents)

| Check | Result |
|---|---|
| Question suite, 65 questions (last/first/count, event lookup, state, context, paraphrase) | 65/65 exact, rules + built-in embedder |
| Of which paraphrased phrasings | 20/20, **but the vocabulary was tuned while writing these, so this is not an independent test** |
| Independent paraphrases, never used during tuning | **5/8**. Misses: "because of heat", "interface went away", "power problem" |
| Anomaly scan vs injected voltage and temperature incidents | 29/29 found, 0 extra flagged |
| Silent-node detection (removed 22 min of one node; silenced another for 30 min) | both found |
| Latency | about 9 ms median, 21 ms p95 on a laptop CPU |
| Ingest | about 21,700 lines in 0.5 s |
| Offline proof | 0 network attempts |

Read the table as a regression test on synthetic data. It is not a claim about real-world accuracy. The 5/8 figure is the honest signal for
the built-in fallback; a neural embedder (MiniLM/BGE) is the intended fix and should be measured the same way.

## 5. Demo script (about 7 minutes)
1. Three terminals: `python gen_logs.py --live data\edge.log`, `python server.py --watch data\edge.log --open`, and the browser. Show the **100% local** badge and the live counter rising.
2. Ask: *When was the last time voltage went above 250 on edge-03?* Click a result row; the timeline marks it.
3. Ask: *What happened around the last over temperature shutdown?* This is the "recall a historical state" moment.
4. Ask a loose one: *When did edge-01 lose network connectivity?* Open "How this was answered".
5. Show the **Unusual activity** list, click an item.
6. Run `python offline_proof.py` and show **0 outbound attempts**. Optionally switch Wi-Fi off and repeat step 2.
7. Show the NPU evidence: AI Hub profile page and the `bench.py` CPU vs NPU numbers (once you have them).

## 6. Limits and risks (say these out loud before a judge does)
- Evaluated only on synthetic logs. Real logs need a parser tweak and a fresh evaluation.
- The built-in embedder is a fallback. Paraphrase quality needs the neural model; the Ollama path (`--embedder ollama`) or the ONNX path provides it.
- Using the hosted Qwen endpoint sends questions and matching log lines to that server. The design is offline-capable, but that specific setup is not offline.
- NPU claims are unverified until `aihub_compile.py` / `bench.py` run on a supported machine. The SLM itself is not on the NPU in this build.
- Relative times ("last 2 hours") are relative to the newest log line, not the wall clock.
- No voice input, no authentication (UI binds to 127.0.0.1 only), single machine.

## 7. Roadmap
Voice via on-device Whisper (AI Hub has a pre-optimized model), SLM on the NPU through Qualcomm Genie, real log parsers (Drain3, syslog, JSON), alert rules from anomaly findings, multi-node sync of memories, retention policy.

## 8. Suggested slide outline
1. Problem: log explosion, cost, privacy. 2. Idea: AI Recall, all local. 3. Architecture (diagram above). 4. Why it works (numbers exact, per-template memory, cited answers). 5. Live demo. 6. Results table with the caveats. 7. Qualcomm angle: embedding model on NPU, AI Hub profile, power and latency. 8. Roadmap and ask.
