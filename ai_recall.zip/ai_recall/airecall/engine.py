"""Ingest + ask: ties parser, embedder, store, planner (and optional local LLM) together."""
from __future__ import annotations

import os
import threading
import time
from dataclasses import asdict
from datetime import datetime

import numpy as np

from . import llm, nlq
from .embedder import get_embedder
from .logparse import parse_line
from .store import LogStore

REL = 0.85  # keep templates scoring within 85% of the best match


def _g(x):
    return f"{x:g}"


class Recall:
    def __init__(self, data_dir="data", embedder="auto", provider="auto", use_llm=False, models_dir="models"):
        self.lock = threading.RLock()  # the UI server and the live watcher share this engine
        self.store = LogStore(data_dir)
        self.emb = get_embedder(embedder, provider, models_dir)
        self.use_llm = use_llm and llm.available()
        saved = self.store.get_meta("embedder")
        if saved and saved != self.emb.name and self.store.tmpl:
            # embedder changed (e.g. hash -> ONNX/NPU): templates are stored, so just re-embed them
            self.store.set_vectors(self.emb.encode(self.store.tmpl))
            self.store.set_meta("embedder", self.emb.name)

    # ---------------- ingest ----------------
    def ingest_lines(self, lines, chunk=5000):
        with self.lock:
            return self._ingest_lines(lines, chunk)

    def _ingest_lines(self, lines, chunk=5000):
        st = dict(lines=0, parsed=0, bad=0, new_templates=0)
        buf = []

        def flush():
            if not buf:
                return
            new = {}
            for r in buf:
                if r["template"] not in self.store.tid and r["template"] not in new:
                    new[r["template"]] = r["kind"]
            if new:
                items = list(new.items())
                self.store.add_templates(items, self.emb.encode([t for t, _ in items]))
                st["new_templates"] += len(items)
            self.store.add_logs(buf)
            buf.clear()

        for line in lines:
            if not line.strip():
                continue
            st["lines"] += 1
            r = parse_line(line)
            if r is None:
                st["bad"] += 1
                continue
            st["parsed"] += 1
            buf.append(r)
            if len(buf) >= chunk:
                flush()
        flush()
        self.store.set_meta("embedder", self.emb.name)
        return st

    def ingest(self, path, reset=False):
        if reset:
            self.store.reset()
        t0 = time.perf_counter()
        with open(path, encoding="utf-8", errors="replace") as f:
            st = self.ingest_lines(f)
        st["seconds"] = round(time.perf_counter() - t0, 2)
        st["embedder"] = f"{self.emb.name} ({self.emb.device})"
        self.store.set_meta("off:" + os.path.abspath(path), str(os.path.getsize(path)))  # so watch() continues from here
        return st

    def watch(self, path, interval=1.0, stop=None, from_start=False, on_batch=None):
        """Live ingestion: follow a growing log file and ingest new complete lines as they arrive.
        Remembers its position, so it resumes after a restart. Pass a threading.Event as `stop`."""
        key = "off:" + os.path.abspath(path)
        with self.lock:
            pos = 0 if from_start else int(self.store.get_meta(key) or 0)
        while not (stop and stop.is_set()):
            try:
                size = os.path.getsize(path)
            except OSError:
                size = 0
            if size < pos:  # file was rotated or truncated
                pos = 0
            if size > pos:
                with open(path, "rb") as f:
                    f.seek(pos)
                    data = f.read()
                cut = data.rfind(b"\n")
                if cut >= 0:  # only whole lines, never a half-written one
                    chunk = data[:cut + 1]
                    st = self.ingest_lines(chunk.decode("utf-8", "replace").splitlines())
                    pos += len(chunk)
                    with self.lock:
                        self.store.set_meta(key, str(pos))
                    if on_batch:
                        on_batch(st)
            if stop:
                stop.wait(interval)
            else:
                time.sleep(interval)

    # ---------------- ask ----------------
    def ask(self, question):
        with self.lock:
            return self._ask(question)

    def _ask(self, question):
        t0 = time.perf_counter()
        s = self.store
        if not s.n_logs():
            return dict(question=question, answer="No logs ingested yet.", evidence=[], plan={}, matched=[], latency_ms=0)
        now = datetime.strptime(s.latest_ts(), nlq.FMT)
        nodes, fields = s.nodes(), s.metric_names()
        rule_plan = nlq.parse(question, nodes, fields, now)
        if rule_plan.mode in ("state", "context"):  # time-travel questions are always planned by rules
            plan = rule_plan
        else:
            plan = (llm.plan_with_llm(question, nodes, fields, now) if self.use_llm else None) or rule_plan
        if plan.mode == "metric":
            answer, evidence, matched = self._metric(plan)
        elif plan.mode == "state":
            answer, evidence, matched = self._state(plan)
        elif plan.mode == "context":
            answer, evidence, matched = self._context(plan)
        else:
            answer, evidence, matched = self._semantic(plan)
        if self.use_llm and evidence:
            lines = [f"{e['ts']} {e['node']} {e['level']} {e['msg']}" for e in evidence]
            answer = llm.phrase_answer(question, answer, lines) or answer
        return dict(question=question, answer=answer, evidence=evidence, plan=asdict(plan),
                    matched=matched, latency_ms=round((time.perf_counter() - t0) * 1000, 1))

    @staticmethod
    def _scope(plan):
        txt = f" on {plan.node}" if plan.node else " across all nodes"
        if plan.t_from or plan.t_to:
            txt += f" between {plan.t_from or 'the start'} and {plan.t_to or 'now'}"
        return txt

    def _auto_threshold(self, plan):
        vals = self.store.metric_values(plan.field, plan.node)
        if len(vals) < 20:
            return None
        med = float(np.median(vals))
        sigma = float(np.median(np.abs(vals - med))) * 1.4826 or float(vals.std()) or 1.0
        return round(med + 6 * sigma if plan.direction != "down" else med - 6 * sigma, 2)

    def _metric(self, plan):
        s, f = self.store, plan.field
        flt = dict(node=plan.node, t_from=plan.t_from, t_to=plan.t_to)
        scope = self._scope(plan)
        note = ""
        if plan.intent in ("max", "min"):
            r = s.metric_extreme(f, plan.intent, **flt)
            if not r:
                return f"No {f} readings found{scope}.", [], []
            word = "highest" if plan.intent == "max" else "lowest"
            return (f"The {word} {f} reading{scope} was {_g(r['value'])} at {r['ts']} on {r['node']}.",
                    [self._ev(r)], [])
        if plan.intent == "avg":
            avg, n = s.metric_avg(f, **flt)
            if not n:
                return f"No {f} readings found{scope}.", [], []
            return f"Average {f}{scope} is {avg:.2f} over {n} readings.", [], []

        op, val = plan.op, plan.value
        if val is None and plan.direction:
            thr = self._auto_threshold(plan)
            if thr is not None:
                op, val = ("<" if plan.direction == "down" else ">"), thr
                note = f" (no threshold given, so I used {_g(val)}: median {'-' if op == '<' else '+'} 6 robust sigmas)"
                plan.op, plan.value, plan.note = op, val, note.strip()
        cond = f"{f} {'above' if op and op.startswith('>') else 'below'} {_g(val)}" if op else f"{f} readings"

        if plan.intent == "count":
            n = s.metric_count(f, op, val, **flt)
            by = s.metric_count_by_node(f, op, val, **flt)
            detail = ", ".join(f"{a}: {b}" for a, b in by if b)
            first = s.metric_rows(f, op, val, order="ASC", limit=1, **flt)
            ev = s.metric_rows(f, op, val, limit=5, **flt)
            ans = f"{n} reading(s) of {cond}{scope}{note}."
            if n and plan.intent == "count" and detail and not plan.node:
                ans += f" By node: {detail}."
            return ans, [self._ev(r) for r in ev], []

        order = "ASC" if plan.intent == "first" else "DESC"
        rows = s.metric_rows(f, op, val, order=order, limit=5 if plan.intent != "list" else 10, **flt)
        if not rows:
            return f"No readings of {cond}{scope}{note}.", [], []
        r = rows[0]
        if plan.intent in ("last", "first"):
            which = "first" if plan.intent == "first" else "last"
            was = cond.replace(f"{f} ", f"{f} was ", 1) if op else f"{f} was recorded"
            ans = f"The {which} time {was}{scope} was {r['ts']} on {r['node']} (reading {_g(r['value'])}){note}."
        else:
            ans = f"Most recent readings of {cond}{scope}{note}: latest was {r['ts']} on {r['node']} ({_g(r['value'])})."
        return ans, [self._ev(x) for x in rows], []

    def _semantic(self, plan):
        s = self.store
        flt = dict(node=plan.node, t_from=plan.t_from, t_to=plan.t_to, level=plan.level)
        scope = self._scope(plan)
        matched = []
        if plan.text:
            qv = self.emb.encode([plan.text])[0]
            cands = s.semantic_templates(qv, k=8)
            if not cands or cands[0][2] < self.emb.min_sim:
                return "I couldn't find a log pattern that matches that question.", [], []
            top = cands[0][2]
            group = [c for c in cands if c[2] >= max(self.emb.min_sim, REL * top)]
            tids = [c[0] for c in group]
            matched = [dict(template=c[1], score=round(c[2], 3)) for c in group]
        else:
            tids = s.event_tids()
        what = f"“{matched[0]['template']}”" if matched else (f"{plan.level} events" if plan.level else "events")

        if plan.intent == "count":
            n = s.count_logs(tids, **flt)
            by = ", ".join(f"{a}: {b}" for a, b in s.count_logs_by_node(tids, **flt))
            ans = f"{n} matching event(s) for {what}{scope}."
            if n and by and not plan.node:
                ans += f" By node: {by}."
            return ans, [self._ev(r) for r in s.logs(tids, limit=5, **flt)], matched

        order = "ASC" if plan.intent == "first" else "DESC"
        rows = s.logs(tids, order=order, limit=5 if plan.intent in ("last", "first") else 10, **flt)
        if not rows:
            return f"No events matching {what}{scope}.", [], matched
        r = rows[0]
        if plan.intent in ("last", "first"):
            which = "first" if plan.intent == "first" else "last"
            ans = f"The {which} matching event ({what}) was at {r['ts']} on {r['node']}: {r['msg']}"
        else:
            ans = f"Found events for {what}{scope}; the most recent was at {r['ts']} on {r['node']}."
        return ans, [self._ev(x) for x in rows], matched

    # ---------------- time travel ----------------
    def _describe(self, snap, head, anchor=None):
        w = snap["window_min"]
        parts = []
        for n, vals in snap["nodes"].items():
            bits = []
            for name, v in vals.items():
                bit = f"{name} {_g(v['value'])}"
                if v["hi"] is not None and (v["hi"] - v["lo"]) > 0.1 * max(abs(v["value"]), 1):
                    bit += f" (range {_g(v['lo'])}-{_g(v['hi'])} within ±{w} min)"
                bits.append(bit)
            parts.append(f"{n}: " + ", ".join(bits))
        text = f"{head}: " + ("; ".join(parts) if parts else "no readings in the 15 minutes before that moment") + "."
        evs = snap["events"]
        if evs:
            kinds = sorted({e["msg"] for e in evs})
            text += f" {len(evs)} event(s) within ±{w} min, e.g. " + "; ".join(kinds[:3]) + "."
        else:
            text += f" No events within ±{w} min."
        rows = {e["id"]: e for e in (snap["lines"] + evs)}
        if anchor:
            rows.pop(anchor["id"], None)
        ordered = sorted(rows.values(), key=lambda e: (e["ts"], e["id"]))
        if anchor:
            ordered = [anchor] + ordered
        return text, ordered[:12]

    def _state(self, plan):
        snap = self.store.snapshot(plan.at, plan.node, plan.window)
        scope = f" on {plan.node}" if plan.node else " across all nodes"
        return (*self._describe(snap, f"State at {plan.at}{scope}"), [])

    def _context(self, plan):
        s = self.store
        qv = self.emb.encode([plan.anchor])[0]
        cands = s.semantic_templates(qv, k=8)
        if not cands or cands[0][2] < self.emb.min_sim:
            return f"I couldn't find an event matching “{plan.anchor}”.", [], []
        top = cands[0][2]
        group = [c for c in cands if c[2] >= max(self.emb.min_sim, REL * top)]
        matched = [dict(template=c[1], score=round(c[2], 3)) for c in group]
        rows = s.logs([c[0] for c in group], node=plan.node, t_from=plan.t_from, t_to=plan.t_to,
                      order="ASC" if plan.anchor_which == "first" else "DESC", limit=1)
        if not rows:
            return f"No “{matched[0]['template']}” event found{self._scope(plan)}.", [], matched
        a = rows[0]
        snap = s.snapshot(a["ts"], a["node"], plan.window)
        head = f"Around the {plan.anchor_which} “{matched[0]['template']}” ({a['ts']} on {a['node']})"
        text, ev = self._describe(snap, head, anchor=self._ev(a))
        return text, ev, matched

    @staticmethod
    def _ev(r):
        e = dict(id=r["id"], ts=r["ts"], node=r["node"], level=r["level"], msg=r["msg"])
        if "value" in r:
            e["value"] = r["value"]
        return e
