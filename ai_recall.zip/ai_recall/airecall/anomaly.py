"""Proactive detection of unusual behaviour in the stored logs. numpy only, no model, runs anywhere.

metric incidents : readings far from a node's normal level (robust z-score: median and MAD, so one spike
                   does not hide itself by inflating the baseline). Consecutive readings are merged.
log gaps         : a node that stops sending logs. Missing logs are a signal too.
"""
from __future__ import annotations

from datetime import datetime

import numpy as np

F = "%Y-%m-%dT%H:%M:%S"


def _dt(s):
    return datetime.strptime(s, F)


def metric_incidents(store, z=6.0, merge_min=5, min_points=30):
    out = []
    for node in store.nodes():
        for f in store.metric_names():
            rows = store.db.execute("SELECT ts, value FROM metrics WHERE name=? AND node=? ORDER BY ts", (f, node)).fetchall()
            if len(rows) < min_points:  # sparse fields (attached to rare events) have no baseline
                continue
            vals = np.array([r[1] for r in rows], float)
            med = float(np.median(vals))
            sig = float(np.median(np.abs(vals - med))) * 1.4826 or float(vals.std()) or 1.0
            zs = (vals - med) / sig
            group = []

            def close():
                if group:
                    pk = max(group, key=lambda i: abs(zs[i]))
                    out.append(dict(kind="metric", node=node, field=f, start=rows[group[0]][0], end=rows[group[-1]][0],
                                    n=len(group), peak=float(vals[pk]), baseline=med, z=float(zs[pk]),
                                    direction="high" if zs[pk] > 0 else "low"))
                    group.clear()

            for i in np.flatnonzero(np.abs(zs) >= z):
                if group and (_dt(rows[i][0]) - _dt(rows[group[-1]][0])).total_seconds() > merge_min * 60:
                    close()
                group.append(int(i))
            close()
    return out


def gap_incidents(store, factor=10, min_gap_s=300, min_points=30):
    out, latest = [], store.latest_ts()
    for node in store.nodes():
        top = store.db.execute("SELECT name FROM metrics WHERE node=? GROUP BY name ORDER BY COUNT(*) DESC LIMIT 1", (node,)).fetchone()
        if not top:
            continue
        ts = [r[0] for r in store.db.execute("SELECT ts FROM metrics WHERE node=? AND name=? ORDER BY ts", (node, top[0]))]
        if len(ts) < min_points:
            continue
        d = np.diff(np.array(ts, dtype="datetime64[s]")).astype("int64")
        typical = float(np.median(d))
        thr = max(factor * typical, min_gap_s)
        for i in np.flatnonzero(d > thr):
            out.append(dict(kind="gap", node=node, field=None, start=ts[i], end=ts[i + 1], seconds=int(d[i]), typical=typical, open=False))
        tail = (_dt(latest) - _dt(ts[-1])).total_seconds()
        if tail > thr:
            out.append(dict(kind="gap", node=node, field=None, start=ts[-1], end=latest, seconds=int(tail), typical=typical, open=True))
    return out


def scan_all(store, z=6.0):
    if not store.n_logs():
        return []
    return sorted(metric_incidents(store, z) + gap_incidents(store), key=lambda i: i["start"], reverse=True)


def describe(i):
    if i["kind"] == "metric":
        return (f"[{i['start']}] {i['node']}: {i['field']} {i['direction']}. peak {i['peak']:g} vs typical "
                f"{i['baseline']:g} (z={abs(i['z']):.0f}, {i['n']} reading(s))")
    mins = i["seconds"] / 60
    if i["open"]:
        return f"[{i['start']}] {i['node']}: SILENT. no logs for {mins:.0f} min (normally every {i['typical']:.0f}s)"
    return f"[{i['start']}] {i['node']}: log gap of {mins:.0f} min until {i['end']} (normally every {i['typical']:.0f}s)"
